## Synopsis

**Matching Game** or Memory Game it is a easy funny game to play that is testing your memory.


## Motivation

This project was made part of the **Udacity Google Course Nanodegree Program** to test the concepts and infprmation that learn.What other good way to learn then putting in practice the knowledge.


## Installation

There is no need for instalation. It is all on the web. 


## Game Rules

The player click any 2 cards.If the cards match then they remain face-up. If not after 1 second there are automatically face down. The gameend when all the cards are beeing clicked and face-up.
After the end of the game you see your time and the number of mooves you made and the star you rate, 3 beeing the best raiting, 0 none.

## Contributors

Adriana Milcov and all the techers from Udacity FEND Program that give us information to learn Web development.

## License

Free to use.