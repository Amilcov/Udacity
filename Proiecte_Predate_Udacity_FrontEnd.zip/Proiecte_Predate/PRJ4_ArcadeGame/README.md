#Arcade Game#

**How to win:**
The Game will be win when the Player have crossed the street avoiding enemies that are on it until he gets safe to the water.

**Characters:**
1 Player and 3 running enemies representing by bugs.

**How to play:**
To start the game open index.html in your browser. You can also do that by right clicking the index.html and select "open with" and then select  any browser ( e.g.: Chrome)
After click the "Start" button, the player can be moved with the arrows: UP, DOWN, LEFT and WRITE to cross the street that has 3 lines.
The starting point of the player is on the grass. Between the grass and the water there is the street.
Enemies are running free on the street. Each enemy has a different speed and run on a randomly line of the street.

**Score:**
The game will show how many times the player cross the street successfully.
The score reset when player hits the bug , or  vice versa.





_**Contributors:**_
The game was developed by Adriana Claudia Milcov from the scratch as part of the Udacity and Google full scolarship:
"Google Developer Front-End Web Developer Nanodegree Program".
