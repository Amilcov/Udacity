   var li_start=0;
   var li_end=0;
   var li_x=2; //has the index of the array_h;  on start of game the boy is centered on array_h (orizontal);
   var li_y=0; //has the index of the array_v   on start of game the boy is centered on array_v (verical);
   var li_direction=0; // will we change to 1: for up and right; to -1: for down and left
   var ls_direction='';
   var game_on=0;   //1 if the game has started
   var array_h  =[-202 , -101 , 0,  101, 202];
   var array_v  =[0 , -90 , -170,  -250, -335, -415];
   var li_pos_x_boy=0;

  //ok: var li_x_bug=[0, -196, -496, -396]; // has the  x position of each bug; these are the starting point of bugs; the dalay of entering in the game of the   bugs is made by diferrent starting points; there are 3 bugs but for the easiness of use=ing it in all the  functions I ve set the bug 1 to be call bug[1],and so on..
  //test
   var li_x_bug=[0, -196, -496, -396];
   var li_y_bug=[0, 1, 1, 1];
   var li_visible_bug=[0, 0 , 0, 0];
   var li_collision=0;
   var li_win=0;



   var p_log=document.getElementById("p_id_log"); //this is just for test; to ceck the (x,y_ position of bugs and the man

//drow "the playground" of the game
  function drawGame (){
    elem_canvas = document.getElementById("id_playground");
    elem_canvas.width=495;
    elem_canvas.height=492;

    ctx=elem_canvas.getContext("2d");

    //the playground of the game
    var img_playground = new Image();
    img_playground.src="img/canvas_all.png";
    img_playground.alt="playground";

    img_playground.onload= function() {
      fill_canvas(img_playground);
    }



    //put the boy_grass.ong image on the start position
    img_boy=document.getElementById('id_boy');

    img_boy.setAttribute("style", "margin-left: 0px");
    img_boy.setAttribute("style", "margin-top: -200px");


    //attach keydown event
    document.addEventListener("keydown", ue_key, false);

    //hide the bugs before the start of the game
    document.getElementById("id_bug1").style.visibility="hidden";
    document.getElementById("id_bug2").style.visibility="hidden";
    document.getElementById("id_bug3").style.visibility="hidden";
  }


  function fill_canvas(img) {
    ctx.drawImage(img, 0, 0, 495, 492);
  }

   //the start button
   function start_game() {


    //Game info
    p_info =document.getElementById("p_id_info");
    //p_info.innerHTML="Playing..";

    //draw start button
    var img_start=document.getElementById("id_img_start");
    img_start.style.visibility="hidden";


     game_on=1;

     //start bugs
     start_bugs();

  }



function ue_key(e){
  var keyCode=e.keyCode;

  if (game_on== 0) {
    return;
  }

  //left arrow was pressed
  if (keyCode == 37 && array_h[li_x] > -102) {
      move_boy("left");
  }

  //right arrow was pressed
  if (keyCode == 39 && array_h[li_x] < 103) {
      move_boy("right");
  }

  //up arrow was pressed
  if (keyCode == 38 && array_v[li_y] > -400) {
      move_boy("up")
  }

  //down arrow was pressed
  if (keyCode == 40 && array_v[li_y] < 0) {
      move_boy("down");
  }

}


function move() {

   if (li_start==li_end) {

  //player arrived at the water
  if (li_y == 5 ) {  reset(1); }

   clearInterval(id_cadru);

   }
   else {
    if( li_direction == -1 ) li_start--;
    if( li_direction == 1 ) li_start++;
    if (( ls_direction == 'right' ) || ( ls_direction == 'left' )) { img_boy.style.left=li_start + 'px'; li_pos_x_boy= li_start;}
    if (( ls_direction == 'up' ) || ( ls_direction == 'down' )) {img_boy.style.top=li_start + 'px';}
   }

}


 function move_boy(direction) {
 ls_direction=direction;
 img_boy=document.getElementById('id_boy');


   //horizontal
   if (direction == 'right') {
    li_start=array_h[li_x];
    li_direction=1;
    li_x++;
    li_end= array_h[li_x];
    var id_cadru=setInterval(move, 1);
   }

   if (direction == 'left') {
    li_start=array_h[li_x];
    li_direction=-1;
    li_x--;
    li_end= array_h[li_x];
    var id_cadru=setInterval(move, 1);
  }


   //vertical
  if (direction == 'up') {
   li_start=array_v[li_y];
   li_direction=-1;
   li_y++;
   li_end= array_v[li_y];
   var id_cadru=setInterval(move, 1);
 }

   if (direction == 'down') {
    li_start=array_v[li_y];
    li_direction=1;
    li_y--;
    li_end= array_v[li_y];
    var id_cadru=setInterval(move, 1);
}


 }



function start_bugs() {
 img_bug1= document.getElementById("id_bug1");
 img_bug2= document.getElementById("id_bug2");
 img_bug3= document.getElementById("id_bug3");

 img_bug1.style.visibility="visible";
 img_bug1.style.left= -196+"px";

 img_bug1.style.top=get_lane(1);
 id_cadru1=setInterval( function(){bug(1)}, 10);

 img_bug2.style.left= -196+"px";
 img_bug2.style.top=get_lane(2);
 id_cadru2=setInterval( function(){bug(2)}, 30);


 img_bug3.style.left= -396+"px";
 img_bug3.style.top=get_lane(3);
 id_cadru3=setInterval( function(){bug(3)}, 40);


};



 function bug(i) {

   //when it reached the final of the road we put it on the  beginning of the road
   if (li_x_bug[i]> 202) {
    li_x_bug[i]=-196;

     if (i == 1) {img_bug1.style.top= get_lane(i)};
     if (i == 2) {img_bug2.style.top= get_lane(i)};
     if (i == 3) {img_bug3.style.top= get_lane(i)};
    }
    else {
     //set the bugs with different speeds
     li_x_bug[i]++;
     if (i==1) {li_x_bug[i]++;}
     if (i==2) {li_x_bug[i]=li_x_bug[i]+2;}

     if( i==2 && li_visible_bug[2]==0 && li_x_bug[i]==-190) {img_bug2.style.visibility="visible"; li_visible_bug[2]=1};
     if( i==3 && li_visible_bug[3]==0 && li_x_bug[i]==-190) {img_bug3.style.visibility="visible"; li_visible_bug[3]=1};

     if (i == 1) {img_bug1.style.left=li_x_bug[1] + 'px'};
     if (i == 2) {img_bug2.style.left=li_x_bug[2] + 'px'};
     if (i == 3) {img_bug3.style.left=li_x_bug[3] + 'px'};
     }


     setTimeout(function(){check_collision()}, 1);

 }



 //generate random on which stone line the bug will run
 function get_lane(ra_bug) {

   var ls_ret;
   var li_lane;


   li_lane= Math.floor(Math.random()*1000)%3 +1;
   li_y_bug[ra_bug]=li_lane;


   //put the  bug on the generated stone line; for each bug will be set different "top" value  because each bug has a different initial position on DOM
   //switch bug0line
   switch (ra_bug*100+li_lane) {

    //bug1
    case 101: ls_ret= "-450px";
              break;

    case 102: ls_ret= "-530px";
              break;

    case 103: ls_ret= "-615px";
              break;

    //bug2
    case 201: ls_ret= "-625px";
              break;

    case 202: ls_ret= "-705px";
              break;

    case 203: ls_ret= "-790px";
              break;

    //bug3
    case 301: ls_ret= "-800px";
              break;

    case 302: ls_ret= "-880px";
              break;

    case 303: ls_ret= "-965px";
              break;


   }

   return ls_ret;


 }




 function check_collision() {

    //Note:  bug take 100%=99px of the width in bug picture; boy take only 60px of the 99px of the boy picture; so boy picture: 20px of space in left+60px boy+20px right space
    //end_bug: li_x_bug[i]+ bug.width(=99px)
    //end_boy: [li_pos_x_boy (=99)-20
    //where these 2 interveals overlap there is a collision:

    //collision 1: bug_end>=li_pos_x_boy+20 && li_bug_end< li_pos_x_boy+(99-20)
    //collision 2: li_x_bug >=start_boy && start_boy<=end_bug

    //test
    //p_info.innerHTML="boy x:"+ li_pos_x_boy+ ";    li_x_bug[1]:"+ li_x_bug[1]+ ";    li_x_bug[2]:"+ li_x_bug[2]+";   li_x_bug[3]:"+ li_x_bug[3] +";   li_y:"+li_y +";    li_y_bug[1]:"+ li_y_bug[1]+ ";    li_y_bug[2]:"+ li_y_bug[2]+";   li_y_bug[3]:"+ li_y_bug[3]+ "li_collision:"+li_collision;
    //check collision in 1th line of stone
    if (li_y ==2 && (
                     (li_y_bug[1]==1 && ( li_x_bug[1]+99>=li_pos_x_boy+20 && li_x_bug[1]+99<=li_pos_x_boy+79 ||
                                          li_x_bug[1]>=li_pos_x_boy+20 && li_x_bug[1]<=li_pos_x_boy+79
                                        )
                     )
                    ||
                    (li_y_bug[2]==1 && ( li_x_bug[2]+99>=li_pos_x_boy+20 && li_x_bug[2]+99<=li_pos_x_boy+79 ||
                                         li_x_bug[2]>=li_pos_x_boy+20 && li_x_bug[2]<=li_pos_x_boy+79
                                       )
                    )
                    ||
                    (li_y_bug[3]==1 && ( li_x_bug[3]+99>=li_pos_x_boy+20 && li_x_bug[3]+99<=li_pos_x_boy+79 ||
                                         li_x_bug[3]>=li_pos_x_boy+20 && li_x_bug[3]<=li_pos_x_boy+79
                                       )
                    )
                   )


        ) {
       li_collision=1;
       //p_info.innerHTML="collision 1;  boy x:"+ li_pos_x_boy+ ";    li_x_bug[1]:"+ li_x_bug[1]+ ";    li_x_bug[2]:"+ li_x_bug[2]+";   li_x_bug[3]:"+ li_x_bug[3] +";   li_y:"+li_y +";    li_y_bug[1]:"+ li_y_bug[1]+ ";    li_y_bug[2]:"+ li_y_bug[2]+";   li_y_bug[3]:"+ li_y_bug[3]+ "li_collision:"+li_collision;
       //p_log.innerHTML += p_info.innerHTML+"<br>";
    }

   // check collision in 2rd line of stone
    if (li_y ==3 && (
                     (li_y_bug[1]==2 && ( li_x_bug[1]+99>=li_pos_x_boy+20 && li_x_bug[1]+99<=li_pos_x_boy+79 ||
                                          li_x_bug[1]>=li_pos_x_boy+20 && li_x_bug[1]<=li_pos_x_boy+79
                                        )
                     )
                    ||
                    (li_y_bug[2]==2 && ( li_x_bug[2]+99>=li_pos_x_boy+20 && li_x_bug[2]+99<=li_pos_x_boy+79 ||
                                         li_x_bug[2]>=li_pos_x_boy+20 && li_x_bug[2]<=li_pos_x_boy+79
                                       )
                    )
                    ||
                    (li_y_bug[3]==2 && ( li_x_bug[3]+99>=li_pos_x_boy+20 && li_x_bug[3]+99<=li_pos_x_boy+79 ||
                                         li_x_bug[3]>=li_pos_x_boy+20 && li_x_bug[3]<=li_pos_x_boy+79
                                       )
                    )
                   )


        ) {
       li_collision=1;
       //p_info.innerHTML="collision 2;  boy x:"+ li_pos_x_boy+ ";    li_x_bug[1]:"+ li_x_bug[1]+ ";    li_x_bug[2]:"+ li_x_bug[2]+";   li_x_bug[3]:"+ li_x_bug[3] +";   li_y:"+li_y +";    li_y_bug[1]:"+ li_y_bug[1]+ ";    li_y_bug[2]:"+ li_y_bug[2]+";   li_y_bug[3]:"+ li_y_bug[3]+ "li_collision:"+li_collision;
       //p_log.innerHTML += p_info.innerHTML+"<br>";
    }

    // check collision in 3rd line of stone
    if (li_y ==4 && (
                     (li_y_bug[1]==3 && ( li_x_bug[1]+99>=li_pos_x_boy+20 && li_x_bug[1]+99<=li_pos_x_boy+79 ||
                                          li_x_bug[1]>=li_pos_x_boy+20 && li_x_bug[1]<=li_pos_x_boy+79
                                        )
                     )
                    ||
                    (li_y_bug[2]==3 && ( li_x_bug[2]+99>=li_pos_x_boy+20 && li_x_bug[2]+99<=li_pos_x_boy+79 ||
                                         li_x_bug[2]>=li_pos_x_boy+20 && li_x_bug[2]<=li_pos_x_boy+79
                                       )
                    )
                    ||
                    (li_y_bug[3]==3 && ( li_x_bug[3]+99>=li_pos_x_boy+20 && li_x_bug[3]+99<=li_pos_x_boy+79 ||
                                         li_x_bug[3]>=li_pos_x_boy+20 && li_x_bug[3]<=li_pos_x_boy+79
                                       )
                    )
                   )


        ) {
       li_collision=1;
       //p_info.innerHTML="collision 3;  boy x:"+ li_pos_x_boy+ ";    li_x_bug[1]:"+ li_x_bug[1]+ ";    li_x_bug[2]:"+ li_x_bug[2]+";   li_x_bug[3]:"+ li_x_bug[3] +";   li_y:"+li_y +";    li_y_bug[1]:"+ li_y_bug[1]+ ";    li_y_bug[2]:"+ li_y_bug[2]+";   li_y_bug[3]:"+ li_y_bug[3]+ "li_collision:"+li_collision;
       //p_log.innerHTML += p_info.innerHTML+"<br>";
    }


  if (li_collision == 1) {
    reset(0);
  }

 }


//reset function will put the player in the start position after winning or loosing a game
function reset(ra_won) {
  if (ra_won == 1) {
    alert ("Congrats! You win!");
    li_win++;
  }
  else {
    li_collision=0;
  }

  p_info.innerHTML="You won: "+li_win+ " game"+ (li_win >1 ? 's' : '' );

  //put the the player in the start position
  li_start=0;
  li_end=0;
  li_x=2;
  li_y=0;
  li_pos_x_boy=0;

  img_boy.setAttribute("style", "margin-left: 0px");
  img_boy.setAttribute("style", "margin-top: -200px");

}
