#FeedReader#


**How to run the application:**
To start the application for testing open index.html in your browser. You can also do that by right clicking the index.html and select "open with" and then select  any browser ( e.g.: Chrome)
If all the test were successfully passed, the 0 failures in the Jasmine section, on the bottom of the page  will wirite "0 failures" and olll the points under the Jasmine text will be green.



_**Contributors:**_
The Automatic Testing Application was developed by Adriana Claudia Milcov as part of the Udacity and Google full scolarship:
"Google Developer Front-End Web Developer Nanodegree Program".
