
if(navigator.serviceWorker) {

  navigator.serviceWorker.register('sw.js').then(
                                                   function(reg) { console.log('Service Worker register with success'); }
                                                 ).
                                                   catch( function(err) {
                                                                          console.log('Service Worker not register');
                                                                        }
                                                          );







         self.addEventListener('fetch', function(event) {
            event.respondWith(
               fetch(event.request).then( function(response) {
                                                                if (response.status==404) {
                                                                                             return new Response("Yak! Page not found");
                                                                                             caches.open('my_buffer').then( function(cache){
                                                                                                                                            /
                                                                                                                                             cache.put(request, response);
                                                                                                                                             
                                                                                                                                            cache.match(request);
                                                                                                                                            caches.match(request);
                                                                                                                                           } );
                                                                                          }
                                                                return response;
                                                             }
                                             ).catch (function() {   return new Response ("Ups! Erroare!");        }
                                             )

            );
         });








}
