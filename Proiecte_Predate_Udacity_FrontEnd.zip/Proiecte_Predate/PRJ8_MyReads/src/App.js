import React, {Component} from 'react'
import {Link} from 'react-router-dom'
import {Route} from 'react-router-dom'
import PropTypes from 'prop-types'
import escapeRegExp from 'escape-string-regexp'
import sortBy from 'sort-by'

import ListBooks from './ListBooks'

import Search from './Search'
import * as BooksAPI from './BooksAPI'
import './App.css'

class BooksApp extends React.Component {
  state = {
    /**
     * TODO: Instead of using this state variable to keep track of which page
     * we're on, use the URL in the browser's address bar. This will ensure that
     * users can use the browser's back and forward buttons to navigate between
     * pages, as well as provide a good URL they can bookmark and share.
     */
    showSearchPage: 'list', //list, search
    books: [],
    shelf_book:''
  }

  componentDidMount() {
      BooksAPI.getAll().then( (books) => {
        this.setState({books})
    })
    }


updateBook = (book, shelf) => {
  BooksAPI.update(book,shelf)
  .then(
    BooksAPI.getAll()
        .then(
              (books) => {  this.setState({books: books})   }
             )

        )
}



  render() {

    return (
      <div className="app">




        <Route exact path ='/' render ={()=> (
          <div>
          <div className="list-books">
            <div className="list-books-title">
              <h1>MyReads</h1>
            </div>
            <div className="list-books-content">
                <div>

                  <div className="bookshelf">
                      <h2 className="bookshelf-title">Currently Reading</h2>
                      <div className="bookshelf-books">
                        <ListBooks shelf_book={"currentlyReading"}

                            books={this.state.books}
                            onMoveBook={this.updateBook}


                        />
                      </div>
                    </div>


                    <div className="bookshelf">
                        <h2 className="bookshelf-title">Want to Read</h2>
                        <div className="bookshelf-books">
                          <ListBooks shelf_book={"wantToRead"}

                              books={this.state.books}
                              onMoveBook={this.updateBook}


                          />
                        </div>
                      </div>


                      <div className="bookshelf">
                          <h2 className="bookshelf-title">Read</h2>
                          <div className="bookshelf-books">
                            <ListBooks shelf_book={"read"}

                                books={this.state.books}
                                onMoveBook={this.updateBook}


                            />
                          </div>
                        </div>

                </div>
            </div>
          </div>

          <div className="open-search">
            <Link to='/search' onClick={() => this.setState({ showSearchPage: 'search' })}
            >Add a book</Link>
          </div>

          </div>

        )}

/>



        <Route path='/search' render={ ()=> (
          <Search
            books={this.state.books}
            onMoveBook={this.updateBook}
            
          />
        )}
        />






      </div>
    )
  }
}

export default BooksApp
