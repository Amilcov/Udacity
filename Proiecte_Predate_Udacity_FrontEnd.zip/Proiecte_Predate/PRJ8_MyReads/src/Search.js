import React , { Component } from 'react';
import {Link} from 'react-router-dom'
import PropTypes from 'prop-types'
import escapeRegExp from 'escape-string-regexp'
import sortBy from 'sort-by'

import * as BooksAPI from './BooksAPI'

class Search extends Component {

  static propTypes= {
     books: PropTypes.array.isRequired
  }


state ={
        query: '',
        showingBooks:[]

}

onUpdateSearch = (query) => {

		this.setState({
			query: query
		},

		this.onSearch(query));
	}


onSearch=(query)=>{
  let findBook;


  if(query) { BooksAPI.search(query)
                          .then((books)=>{


                                           if(books.length){
                                                            books.forEach((book,index)=>{
                                                            let findBook=this.props.books.find((b)=>b.id===book.id);
                                                                 book.shelf=findBook? findBook.shelf:'none';


                                                                 let book_cover = book.imageLinks ? book.imageLinks.smallThumbnail : '';
                                                                 book.cover=book_cover;




                                                              });
                                                            this.setState({showingBooks:books})
                                           }else{
                                                 this.setState({showingBooks:[]})
                                           }



                                        });
    }else{


      this.setState({showingBooks:[]})
    }


  }



  render() {
    return (

<div>

      <div className="search-books">
         <div className="search-books-bar">
            <Link className="close-search" onClick={() => this.setState({ showSearchPage: 'list' })}  to="/">Close</Link>
            <div className="search-books-input-wrapper">
            {

           }
              <input type="text" placeholder="Search by title or author" value={this.state.query}
              onChange ={ (event)=>{ console.log("value:"+this.state.query); this.onUpdateSearch(event.target.value) }}
              />

           </div>

        </div>




        <div className="search-books-results">
        <ol className="books-grid">
        {

          this.state.showingBooks.map ( book => (
           <li key={book.id}>

            <div className="book">
              <div className="book-top">

                <div className="book-cover" style={{ width: 128, height: 188, backgroundImage:  `url(${book.cover})` }}  ></div>
                <div className="book-shelf-changer">
                <select  value={book.shelf}  onChange={(event)=> this.props.onMoveBook(book, event.target.value ) }>
                  <option  value="move" disabled>Move to...</option>
                  <option  value="currentlyReading" >Currently Reading</option>
                  <option  value="wantToRead">Want to Read</option>
                  <option  value="read">Read</option>
                  <option  value="none">None</option>
                </select>
                </div>
              </div>
              <div className="book-title">{book.title}</div>
              <div className="book-authors">{book.authors} </div>
            </div>
          </li>
        ))}


          </ol>

        </div>

      </div>

      <div>

      </div>





      </div>
      )
    }
  }

      export default Search
