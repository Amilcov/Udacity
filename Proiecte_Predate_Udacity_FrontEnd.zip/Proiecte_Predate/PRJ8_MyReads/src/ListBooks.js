import React from 'react'
import {BrowserRouter} from 'react-router-dom'
import ReactDOM from 'react-dom'
import PropTypes from 'prop-types'
import sortBy from 'sort-by'
import Search from './Search'
import * as BooksAPI from './BooksAPI'

import './App.css'

class ListBooks extends React.Component {


  static propTypes= {
     books: PropTypes.array.isRequired
  }


/*  state = {
    //
    //  * TODO: Instead of using this state variable to keep track of which page
    //  * we're on, use the URL in the browser's address bar. This will ensure that
    //  * users can use the browser's back and forward buttons to navigate between
    //  * pages, as well as provide a good URL they can bookmark and share.
    //
    showSearchPage: 'search', //list, search
    books: []
  }
*/

  render() {
   //const books = this.props.books
    let shelf_book= this.props.shelf_book




  //books.sort(sortBy('title'))
    return (


                <ol className="books-grid">
                { this.props.books.filter(book => book.shelf == shelf_book).map ( book => (

                   <li key={book.title}>

                    <div className="book">
                      <div className="book-top">

                        <div className="book-cover" style={{ width: 128, height: 188, backgroundImage: `url(${book.imageLinks.smallThumbnail})`  }}></div>
                        <div className="book-shelf-changer">
                        <select value={book.shelf} onChange={(event)=> this.props.onMoveBook(book, event.target.value ) }>
                          <option value="move" disabled>Move to...</option>
                          <option value="currentlyReading">Currently Reading</option>
                          <option value="wantToRead">Want to Read</option>
                          <option value="read">Read</option>
                          <option value="none">None</option>
                          </select>
                        </div>
                      </div>
                      <div className="book-title">{book.title}</div>
                      <div className="book-authors">{book.authors} </div>
                    </div>
                  </li>

                ))}
                </ol>





    )
  }
}

export default ListBooks
