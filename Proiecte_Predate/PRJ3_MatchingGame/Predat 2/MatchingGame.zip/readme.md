## Synopsis

**Matching Game** or Memory Game it is an easy funny game to play that is testing your memory.


## Motivation

This project was made part of the **Udacity Google Course Nanodegree Program** to test the concepts and information that we learn. What other good way to learn then putting into practice the knowledge.


## Installation

There is no need for instalation. It is all on the web. 


## Game Rules

The player click any 2 cards.If the cards match then they remain face-up. If not, after 1 second there are automatically face down. The game end when all the cards are beeing clicked and face-up.
After the end of the game you see your time and the number of moves you made and the star you rated, 3 beeing the best raiting.

## Contributors

Adriana Milcov and all the techers from Udacity FEND Program that give us information to learn Web development.

## License

Free to use.